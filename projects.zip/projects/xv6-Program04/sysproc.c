#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"


int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

// *** JJ*** Addition for Program 04 - Creating system calls in xv6
// This is where we are going to define the system calls

// Increment "magic" attribute in cpu struct by value.
int sys_incMagic(void) {
	
	// inc will be the amount to increment the magic number.
	int inc;
	
	// Get the argument from the stack.
	if(argint(0, &inc) < 0)
		return -1;
	
	// Disable interrupts and increment number.
	pushcli();
	mycpu()->magic += inc;
	popcli();
	
	return 0;
}

// Return the current value of magic from the cpu struct.
int sys_getMagic(void) {

	int magic;
	
	// Disable interrupts and get the magic number.
	pushcli();
	magic = mycpu()->magic;
	popcli();
	
	return magic;
}

// Print out the name of the current process.
int sys_getProcName(void) {
	
	char *procName;
	//pushcli();
	procName = myproc()->name;
	//popcli();

	cprintf("%s", procName);

	return 0;
}

// Modify the name of the current process to "newName."
int sys_modProcName(void) {
	int stringptr;
	
	if (argint(0, &stringptr) < 0)
		return -1;
	cprintf("called modeProcName(\"%s\")\n", (char *) stringptr);
	
	
	
	char *string = (char *) stringptr;
	for (int i = 0; string[i] != '\0' ; i++) {
		cprintf("%s", string[i]);
	}
	cprintf("\n");
	
	/*
	char* string = (char *) stringptr;
	
	//cprintf("sizeof stringptr: %d\n", sizeof(string)/sizeof(string[0]));
	
	*/
	
	return stringptr;
}
