#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void) {
	
	printf(1, "Initial value of magic: %d\n", getMagic());
	incMagic(5);
	printf(1, "Value of magic after increment: %d\n", getMagic());
	
	
	printf(1, "getProName() ----------------------\n");
	getProcName();
	
	printf(1, "modProcName() ---------------------\n");
	modProcName("newNmae");
	getMagic();
	
	/*
	printf(1, "call returned %d\n", incMagic(5));
	printf(1, "call returned %d\n", getMagic());
	printf(1, "call returned %d\n", getProcName());
	printf(1, "call returned %d\n", modProcName("df"));
	
	printf(1, "dereferensing %s\n", (char *) modProcName("sdf"));
	
	*/
	exit();
}
