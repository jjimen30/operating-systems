
#include "queue.h"

/* Jorge Jimenez
 * CS 3100 Operating Systems - Summer 2021
 * 
 * Description:
 * From the assignment page on canvas
 * "Your job for this assignment ... create the following public 
 * functions to manipulate the stack 
 * queue *createq(void);   
 * bool enqueue(queue *, person); 
 * person dequeue(queue *);   
 * bool isemptyqueue(queue *); 
 * bool emptyq(queue *);     
 * bool freeq(queue *);  "
 */

// ==================
// HELPERS
// ===================
person emptyperson(void);
bool nullqueue(queue *);
void parrow(void);

// ==================
// QUEUE FUNCTIONS
// ===================

// createq is a function that creates a new queue using malloc
// if the queue is not created a value of NULL is returned
queue *createq(void){       
	queue *newQueue;
	newQueue = (queue *) malloc(sizeof(queue));
	
	// If malloc fails do not try to access the head and tail
	// **** just return NULL *** 
	if (newQueue == NULL)
		return NULL;
		
	// Set the head and the tail of the new queue to NULL
	newQueue->head = NULL;
	newQueue->tail = NULL;
	return newQueue;
}

// enqueue is a function that adds an element to the queue, it requires
// a pointer to the queue and a person type as parameters, it returns a
// bool type (true on success and false on failure)
bool enqueue(queue * q, person newPerson){
	// Check to make sure the queue pointer points to something.
	if (nullqueue(q))
		return false;
	
	// Allocate space for newnode, a node type, in the heap
	node *newnode;
	newnode = (node *) malloc(sizeof(node));
	
	if (newnode == NULL) {
		printf("There was a problem allocating memory");
		return false;
	}
	
	// Copy the new person into the node
	newnode->value = newPerson;
	
	// If the queue is empty, set the head to point to the newnode
	if (isemptyqueue(q)) {
		q->head = newnode;
	} else {
	// Else, set the next field of the node at the tail 
	// pointer to point to newnode
		q->tail->next = newnode;
	}
	
	newnode->next = NULL;
	q->tail = newnode;
}


// dequeue is a function that removes a node from a given queue and 
// returns the record stored there.
person dequeue(queue *q){    // if queue is NULL or empty, return blank person
	// Check to make sure the queue pointer points to something
	if (nullqueue(q))
		return emptyperson();
	
	if (q->head == NULL) {
		printf("The queues passed in is empty");
		return emptyperson();
	}
	
	// Copy the value of the node at the stack head
	person p = q->head->value;
	
	node *temp = q->head;
	q->head = temp->next;
	
	free(temp);
	temp = NULL;
	
	return p;
}

// isemptyq returns true if the queue is NULL or empty, false if there 
// are nodes in the queue
bool isemptyqueue(queue *q){ // parameter is a pointer to the queue
	// Check to make sure the queue pointer points to something
	if (nullqueue(q))
		return true;
		
	if (q->head == NULL) {
		return true;
	}
	
	return false;
}

// empytyq is a function that removes all nodes in the queue
// since this is a heap we need to manage it, return false if queue is NULL
bool emptyq(queue *q){     // return true if queue is emptied
	// Is the queue pointer pointing to something
	if (nullqueue(q))
		return false;
		
	// Is the queue already empty
	if (q->head == NULL && q->tail == NULL)
		return true;
	
	
	node *nextnode = q->head;
	node *current = q->head;
	
	// Free up the space associated with the nodes in the queue
	while (nextnode != NULL) {
		nextnode = current->next;
		free(current);
		current = nextnode;
	}
	
	q->head = NULL;
	q->tail = NULL;
}

// freeq is a function that will free the memory for the queue if the 
// queue is empty.  It returns false if queue is not empty, true if freed
bool freeq(queue *q){      // parameter is a pointer to the queue
	// Check to make sure the queue pointer points to something
	if (nullqueue(q))
		return true;
	
	if (!isemptyqueue(q))
		return false;
	
	free(q);
	q = NULL;
	return true;
}

//=======================================
// HELPER FUNCTIONS
//=======================================

// Returns an empty person
person emptyperson() {	
	person emptyPerson;
	strcpy(emptyPerson.name, "");
	emptyPerson.age = 0;
	
	return emptyPerson; 
}

// Returns true if the queue is null and prints an error statement
bool nullqueue(queue *q) {
	if (q == NULL) {
		printf("\nERROR: attempt to use NULL pointer\n");
		return true;
	}
	
	return false;
}
//==================================================================
// The following are not used in this file but are used for testing
//==================================================================

void printqueue(queue *q) {
		if (q == NULL)
		printf("*******************************");
	
	if (nullqueue(q)) {
		printf("Trying to access a null queue");
		return;
	}
	
	printf("   HEAD\n");
	node *nextnode = q->head;
	while (nextnode != NULL) {
		parrow();
		printf("%s\n", nextnode->value.name);
		nextnode = nextnode->next;
	}
	parrow();
	printf("    TAIL\n");
}

// Used to debugg output
void parrow() {
	printf("    .    \n");
	printf("   / \\    \n");
	printf("    |    \n");
}
