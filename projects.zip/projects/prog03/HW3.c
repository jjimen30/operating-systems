#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <strings.h>
#include "helper.h"

/*
 * CS 3100 Operating Systems - Summer 2021
 * Program 03 - Creating new processes with fork
 * 
 * Description:
 * From the assignment page on canvas
 * ". . . create a program that reads a binary random access 
 * file and finds the min and max. Your program will either 
 * use one process or it will use four processes (parallel computing) 
 * to achieve the answer. In order for your forked processes to work 
 * they must use pipes."
 */
 
int main(int argc, char *argv[]) {
	
	// Check process arguments
	if (argc < 3) {
		printf("Usage: HW3 <1 or 4> <name of file to read>\n");
		return 1;
	}
	
	// Cast the second argument from *char to int
	int numForks = atoi(argv[1]);
	char *filename = argv[2];
	
	// numForks must be greater than 0
	if (numForks < 1) {
		printf("Usage: HW3 <1 or 4> <name of file to read>\n");
		return 1;
	}
	
	printf("My name is: Jorge\n\n");
	
	// Time measuring variables
	clock_t runtime;
	struct timeval start, end;
	
	// Start timers 
	runtime = clock();
	gettimeofday(&start, NULL);
	
	// Piping
	int cp[2]; // Pipe array
	char ch; // Used to read from the pipe
	
	if (pipe(cp) < 0)
		printf("didn't work, couldn't not establish pipe.\n");
		
	int rc;
	
	// Run for the number of time passed in to the parent Sprocess
	for(int i = 0; i < numForks; i++) {
		rc = fork();
		
		if (rc == 0) {
		
			close(1);       //close stdout
			dup2(cp[1], 1); //move stdout to pipe of cp[1]
			close(0);       //close stdin
			close(cp[0]);   //close pipe in 
			
			char child[12];
			sprintf(child, "%d", i);
		
			execl("minmax", "minmax",  child, filename, (char *) 0);
		}
	}
	
	if (rc) {
		
		close(cp[1]); //if you don't close this part of the pipe 
	        // then the while loop (three lines down) will never return
	        
		while( read(cp[0], &ch, 1) == 1) {
				printf("%c",ch);
		}

	}
	
	// Get elapsed times 
	runtime = clock() - runtime;
	gettimeofday(&end, NULL);


	printf("Wall clock time %9f seconds, main CPU time %9f.\n", 
			elapsedWallTime(&start, &end), elapsedCPUTime(runtime));
	return 0;	
}
