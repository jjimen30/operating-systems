#include<stdio.h>

int main() {
	printf("The min: and max");
	return 0;	
}
