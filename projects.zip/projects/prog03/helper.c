#include "helper.h"

/*
 * CS 3100 Operating Systems - Summer 2021
 * Program 03 - Creating new processes with fork
 * 
 * Description:
 * From the assignment page on canvas
 * ". . . create a program that reads a binary random access 
 * file and finds the min and max. Your program will either 
 * use one process or it will use four processes (parallel computing) 
 * to achieve the answer. In order for your forked processes to work 
 * they must use pipes."
 */
 


// Takes two struct timevals and returns the time elapsed
double elapsedWallTime(struct timeval *start, struct timeval *end) {
	// Total time
	double wallTime = (double) (end->tv_usec - start->tv_usec) /1000000 +
					  (double) (end->tv_sec - start->tv_sec);
					  
	return wallTime;
}

// Convert clock_t runtime to secondss
double elapsedCPUTime(clock_t runtime) {
	double total_time = ((double)runtime)/CLOCKS_PER_SEC;
	return total_time;
}
