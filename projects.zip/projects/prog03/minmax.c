#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include "helper.h"

//** JJ** Modified for HW3
 int main(int argc, char * argv[]) {

	const char * filename;  // name of file to read
	FILE * ft;  // file handle for the file
	int num,    // the number of integer values in the file
	    i,      // loop control variable for reading values
	    childNum, // The child number
	    temp=0; // used to store each value read from the file
		
	long size;  // size in bytes of the input file
	
	
	
/*********************************************************************/
	// Time measuring variables
	clock_t runtime;
	struct timeval start, end;
	
	// Start timers 
	runtime = clock();
	gettimeofday(&start, NULL);
	
    if (argc < 3) {  // not enough arguments, need output file name
		printf("number of args %d", argc);
        printf("Usage: minmax <int childnum> <filename>\n");
        return 1;
    }

	// Parse the arguments
	childNum = atoi(argv[1]);
    filename = argv[2];  // read the file named on the command line
	
	ft= fopen(filename, "rb") ;
	if (ft) {
		// *** JJ** Modified for HW3
		//pid = getpid();
		fseek (ft,0,SEEK_END); //go to end of file
		size = ftell(ft);      //what byte in file am I at?
		fseek (ft,0,SEEK_SET); //go to beginning of file
		num = (int)size / (int)sizeof(int); // number of integer values
				
		int min, max;
		int first = 1;
		
		// now read and print out the values
		for(i = 0; i < num; i++){
			fread(&temp,sizeof(int),1,ft);

			//*** jj*** Added the minmax code for the assignament
			// Set max to the first number 
			if (first) {
				max = temp;
				min = temp;
				
				first = 0;
			}
			
			// Update the min and max
			if (temp < min) min = temp;
			if (temp > max) max = temp;
			
		}

		// Get elapsed times 
		runtime = clock() - runtime;
		gettimeofday(&end, NULL);
		
		printf("child #: %d | pid:  %d  | min: %d  |  max: %d | Wall(sec): %6f | CPU(sec): %9f\n", 
				childNum, (int) getpid(), min, max, elapsedWallTime(&start, &end), elapsedCPUTime(runtime));

		fclose(ft);  // close the file now that we're done
	} else {
		printf("There was a problem opening the file %s", filename);
	}
	printf("\n");
	
	
	return 0;
}

