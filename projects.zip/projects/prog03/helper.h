#include <time.h>
#include <sys/time.h>
#include <time.h>

double elapsedWallTime(struct timeval *start, struct timeval *end);

double elapsedCPUTime(clock_t runtime);
